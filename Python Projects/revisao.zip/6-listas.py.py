lista = [25, 32, 19, 21, 29, 27, 27, 26]

lista.append(15)

lista.pop()

lista.pop(4)

lista.remove(19)

print(len(lista))

print(lista.count(27))

print([1, 3] + [8, 14])

