lista1 = [25, 32, 19, 21, 29, 27, 27, 26]

lista2 = lista1

lista1.pop(0)

print(lista2)


# Slicing
print(lista1[2:5])
print(lista1[4:6])
print(lista1[:4])
print(lista1[4:])
print(lista1[::3])
print(lista1[-1:-4:-1])