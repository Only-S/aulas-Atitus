
# Trecho 1
a = 1
while a < 5:
    a += 1
print(a)

print('-' * 10)

# Trecho 2
a = 1
while a <= 5:
    print(a)
    a += 1
print(a)

print('-' * 10)

# Trecho 3
a = 0
while a < 5:
    a += 1
    print(a)
print(a)

print('-' * 10)

# Trecho 4
a = 6
b = 0
while (a - 2) > (b + 1):
    print(f"{a} - {b}")
    a -= 1
print(a)